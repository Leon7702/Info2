package Lab08;

public class OverflowException extends Exception {

	public OverflowException(String errorMessage) {
        super(errorMessage);
    }
}
