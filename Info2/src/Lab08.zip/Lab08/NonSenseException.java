package Lab08;

public class NonSenseException extends Exception {

	public NonSenseException(String errorMessage) {
        super(errorMessage);
    }
}
