package Lab08;

public class UnderflowException extends Exception {

	public UnderflowException(String errorMessage) {
        super(errorMessage);
    }
}
